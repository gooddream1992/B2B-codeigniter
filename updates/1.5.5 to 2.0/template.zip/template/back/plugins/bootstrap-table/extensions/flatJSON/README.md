# Table flatJSON

Use Plugin: [bootstrap-table-flatJSON](https://github.com/djhvscf/bootstrap-table-flatJSON)

## Usage

```html
<script src="extensions/flatJSON/bootstrap-table-flatJSON.js"></script>
```

## Options

### flat

* type: Boolean
* description: Set true to flat the JSON object.
* default: `false`
